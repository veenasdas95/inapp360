<x-app-layout>
    <x-slot name="header">
        <h2 class="font-semibold text-xl text-gray-800 leading-tight">
            {{ __('Dashboard') }}
        </h2>
    </x-slot>

    <div class="py-12">
        <div class="max-w-7xl mx-auto sm:px-6 lg:px-8">
            <div class="bg-white overflow-hidden shadow-sm sm:rounded-lg">
                <div class="p-6 text-gray-900">
                    {{ __("You're logged in!") }}
                </div>
            </div>
        </div>
    </div>
    @php
        $userEmail = Auth::user()->email;
        $userName = Auth::user()->name;
     
    @endphp
    @if ($userEmail == "admin@example.com")
       
   
    <div class="container">
    
    
    
</div>
<div class="container">
   
 <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <!-- Page Content -->
    @if(session('success'))
        <div class="alert alert-success">{{ session('success') }}</div>
    @endif
    <div class="row mt-4">
      
      <div class="col-md-12">
                <h2 class="mb-4">Employee List (12)</h2>
                <div class="d-flex justify-content-between mb-3">
                    <form action="{{ route('import') }}" method="POST" enctype="multipart/form-data" class="d-flex align-items-center">
                        @csrf
                        <div class="form-group p-0 me-3">
                            <label for="file" class="form-label">CSV File</label>
                            <input type="file" name="file" class="form-control">
                        </div>
                        <button type="submit" class="btn btn-primary">Import</button>
                    </form>
                </div>
            </div>
       <div class="col-md-12">   
        </div>
        <!-- Employee Table -->
        <table class="table table-striped">
          <thead class="thead-dark">
            <tr>
              <th> Name</th>
              <th>Email</th>
              <th>Phone</th>
              <th>Designation</th>
              <th>Date of Joining</th>
            </tr>
          </thead>
          <tbody>
             @foreach ($users as $user)
                <tr>
                    <td>{{ $user->name }}</td>
                    <td>{{ $user->email }}</td>
                    <td>{{ $user->phone }}</td>
                    <td>{{ $user->designation }}</td>
                    <td>{{ $user->doj }}</td>
                </tr>
            @endforeach
            <!-- Additional rows can be added here -->
          </tbody>
        </table>
      </div>
    </div>
  </div>
@else
<p>Welcome {{ $userName }}.</p>

@endif
</x-app-layout>
