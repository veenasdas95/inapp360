<p>Hello {{ $user->first_name }},</p>

<p>Welcome to the application. You can log in using the following credentials:</p>

<p>Email: {{ $user->email }}<br>
Password: {{ $password }}</p>

<p>Please reset your password after your first login.</p>

<p><a href="{{ route('login') }}">Login here</a></p>
