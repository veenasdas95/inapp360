<?php

namespace App\Http\Controllers\Auth;

use App\Http\Controllers\Controller;
use Illuminate\Http\RedirectResponse;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Hash;
use Illuminate\Validation\Rules\Password;

class LoginController extends Controller
{
   
    protected function authenticated(Request $request, $user)
    {
    if ($user->password_changed_at === null) {
        return redirect()->route('password.request');
    }

    return redirect()->intended($this->redirectPath());
   }
}

