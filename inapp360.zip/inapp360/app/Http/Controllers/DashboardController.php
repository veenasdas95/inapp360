<?php

namespace App\Http\Controllers;

use App\Models\User; // Import the User model
use Illuminate\Http\Request;

class DashboardController extends Controller
{
    public function index()
    {
        // Fetch all users (adjust the query as needed)
        $users = User::all(['name', 'email','phone','designation','doj']);
        
        // Pass data to the view
        return view('dashboard', compact('users'));
    }
}
