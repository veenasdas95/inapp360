<?php

namespace App\Imports;

use App\Models\User;
use Illuminate\Support\Str;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Facades\Mail;
use App\Mail\UserWelcomeMail; 
use Maatwebsite\Excel\Concerns\ToModel;
use Maatwebsite\Excel\Concerns\WithHeadingRow;
use Illuminate\Support\Facades\Log;

class UsersImport implements ToModel, WithHeadingRow
{
    public function model(array $row)
    {
        // Validate required fields
        if (empty($row['email']) || empty($row['first_name']) || empty($row['last_name'])) {
            Log::warning('Missing required fields in import row: ' . json_encode($row));
            return null; // Skip this record
        }

        // Check if user with the given email already exists
        if (User::where('email', $row['email'])->exists()) {
            Log::info('Duplicate user skipped: ' . $row['email']);
            return null; // Skip this record
        }

        $password = "password"; // Use a fixed password for now

        // Create a new user
        $user = User::create([
            'name' => $row['first_name'] . ' ' . $row['last_name'],
            'email' => $row['email'],
            'phone' => $row['phone_number'],
            'designation' => $row['designation'],
            'doj' => $row['doj'],
            'password' => Hash::make($password),
        ]);

        // Send welcome email
        Mail::to($row['email'])->send(new UserWelcomeMail($user, $password));

        return $user;
    }
}
