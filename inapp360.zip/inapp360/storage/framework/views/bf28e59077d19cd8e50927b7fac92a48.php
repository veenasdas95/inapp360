<p>Hello <?php echo e($user->first_name); ?>,</p>

<p>Welcome to the application. You can log in using the following credentials:</p>

<p>Email: <?php echo e($user->email); ?><br>
Password: <?php echo e($password); ?></p>

<p>Please reset your password after your first login.</p>

<p><a href="<?php echo e(route('login')); ?>">Login here</a></p>
<?php /**PATH C:\xampp\htdocs\inapp360\resources\views/emails/welcome.blade.php ENDPATH**/ ?>